package app;
import app.entidade.Pessoa;
import app.repositorio.PessoaDAO;
import app.repositorio.Repositorio;

public class App {
    public static void main(String[] Args) {
        App app = new App();
        app.executar();
    }

    public void executar() {
        PessoaDAO exe = Repositorio.pessoas();
        Pessoa pessoa1 = new Pessoa();
        Pessoa pessoa2 = new Pessoa();
        Pessoa pessoa3 = new Pessoa();
        Pessoa pessoa4 = new Pessoa();
        Pessoa pessoa5 = new Pessoa();
        Pessoa pessoa6 = new Pessoa();

        System.out.println("--ADICIONAR--\n");
        System.out.println("------------------------------");

        pessoa1.setNome("Leonardo");
        pessoa1.setSobrenome("Macedo");
        pessoa1.setId(1);

        pessoa2.setNome("Carl");
        pessoa2.setSobrenome("Johnson");
        pessoa2.setId(2);


        pessoa3.setNome("Cleber");
        pessoa3.setSobrenome("Machado");
        pessoa3.setId(3);


        pessoa4.setNome("Peter");
        pessoa4.setSobrenome("Parker");
        pessoa4.setId(4);


        pessoa5.setNome("Jaílson");
        pessoa5.setSobrenome("Mendes");
        pessoa5.setId(5);


        pessoa6.setNome("Professor");
        pessoa6.setSobrenome("Leanderson");
        pessoa6.setId(6);

        exe.adicionar(pessoa1);
        exe.adicionar(pessoa2);
        exe.adicionar(pessoa3);
        exe.adicionar(pessoa4);
        exe.adicionar(pessoa5);
        exe.adicionar(pessoa6);


        pessoa5.setNome("Marco");
        pessoa5.setSobrenome("Reus");
        pessoa5.setId(5);
        exe.atualizar(pessoa5);

        exe.obterPeloId(1);
        exe.deletarPeloId(3);
        System.out.println("Todos da lista:\n "+ exe.obterTodos());
    }
}