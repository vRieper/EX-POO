package app.repositorio;
import app.entidade.Pessoa;
import java.util.ArrayList;
import java.util.List;

public interface PessoaDAO{

    public default int adicionar(Pessoa p){return 0;}
    public default void atualizar(Pessoa p){}
    public default void deletarPeloId(int id){}
    public default Pessoa obterPeloId(int id){return null;}
    public default List<Pessoa> obterTodos(){ArrayList<Pessoa> lista = new ArrayList<>();return lista;}
}