package app.repositorio;

public class PessoaDAOlmpl {private Map<Integer, Pessoa> dados = new HashMap<>();
    private int identificador = 1;

    @Override
    public int adicionar(Pessoa p) {
        dados.put(identificador, p);
        System.out.println(p);
        System.out.println("------------------------------");
        identificador ++;
        return identificador;
    }

    @Override
    public void atualizar(Pessoa p) {
        System.out.println('\n');
        dados.replace(p.getId(), p);
    }

    @Override
    public void deletarPeloId(int id) {
        id = identificador;
        dados.remove(id);
    }

    @Override
    public Pessoa obterPeloId(int id) {
        System.out.println('\n');
        System.out.println("Pessoa obtida:");
        Pessoa nome;
        nome = dados.get(id);
        System.out.println(nome);
        return nome;
    }

    @Override
    public List<Pessoa> obterTodos() {
        System.out.println("\n");
        ArrayList<Pessoa> lista = new ArrayList<>(dados.values());
        return lista;
    }
}
