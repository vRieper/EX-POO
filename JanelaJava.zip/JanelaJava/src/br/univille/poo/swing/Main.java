package br.univille.poo.swing;

public class Main {

    public static void main(String[] args) {
        TelaDeEntrada janela = new TelaDeEntrada();
        janela.setVisible(true);
    }

}
