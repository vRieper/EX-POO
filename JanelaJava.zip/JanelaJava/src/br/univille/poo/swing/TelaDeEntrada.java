package br.univille.poo.swing;

import javax.swing.*;
import java.awt.*;

public class TelaDeEntrada extends JFrame{

    private JPanel rootJPanel1;
    private JPanel rootJPanel2;


    TelaDeEntrada(){

        rootJPanel1 = new JPanel();
        rootJPanel2 = new JPanel();

        setTitle("Login");

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        add(rootJPanel1);
        add(rootJPanel2);

        FlowLayout layout = new FlowLayout();
        rootJPanel1.setLayout(new GridLayout(2,2));
        rootJPanel2.setLayout(layout);
        
        JPanel usuario = new JPanel();
        usuario.add(new JLabel("Login :"));

        JTextField tusuario = new JTextField(20);

        JPanel p3 = new JPanel();
        p3.add(new JLabel("Password :"));

        JPasswordField p4 = new JPasswordField(20);

        JButton botao1 = new JButton("Entrar");
        JButton botao2 = new JButton("Novo Cadastro");

        rootJPanel1.add(usuario);
        rootJPanel1.add(tusuario);
        rootJPanel1.add(p3);
        rootJPanel1.add(p4);
        rootJPanel2.add(botao1);
        rootJPanel2.add(botao2);

        add(rootJPanel1, "North");
        add(rootJPanel2, "South");

        setSize(500, 150);

    }
}
