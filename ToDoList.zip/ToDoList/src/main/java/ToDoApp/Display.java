package ToDoApp;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Display {

    private Scanner read  ;
    private ToDoList toDoList;
    private FileHandler salvararquivo;
    private Print print;
    private SimpleDateFormat SDF;



    public Display() throws IOException, ClassNotFoundException {
        read = new Scanner(System.in);
        toDoList = new ToDoList();
        salvararquivo = new FileHandler();
        SDF = new SimpleDateFormat("MM-dd-yyyy");

        FileHandler fileHandler = new FileHandler();
        toDoList.setToDoList(fileHandler.loadFromFile());
        print = new Print(toDoList.getToDoList());
    }

    public String userInput() {
        return read.nextLine();
    }

    public void start() throws IOException, ClassNotFoundException {
        print.printWelcome();
        response();
    }

    public void response() {
        while (true) {
            print.printOptions();

            switch (userInput()) {
                case "1":
                    orderListOptions();
                    break;
                case "2":
                    addTask();
                    break;
                case "3":
                    editTask();
                    break;
                case "4":
                    quitAndSave();
                    return;
                default:
                    print.printNotValiableOption();
            }
            print.printPressEnterForMenu();
            userInput();
        }

    }

    public void addTask() {
        System.out.println("Adicionar nova tarefa \n");
        System.out.println("Nomiar tarefa:");

        Task task = new Task();
        task.setTitle(userInput());
        System.out.println("Nome do Projeto");
        task.setProjectName(userInput());
        System.out.println("Para qual dia? (MM-dd-yyyy)");

        while (true) {
            try {
                task.setDueDate(SDF.parse(userInput()));
                break;
            } catch (ParseException e) {
                print.printWrongDateFormat();
            }
        }

        Date date = new Date();
        String strDate = SDF.format(date);
        try {
            task.setCreatedDate(SDF.parse(strDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        toDoList.addToDo(task);
        System.out.println("Task: " + task.getTitle() + " was added");
    }
    public void quitAndSave() {
        print.printWhenQuitApplication();
        try {
            salvararquivo.saveToFile(toDoList.getToDoList());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getTaskNumberAndChangeItToDone() {

        System.out.println("Qual tarefa você deseja marcar como finalizada? \n ");
        print.printOnlyIndexAndNameOfTask();
        System.out.println("\n Nome da tarefa que voce deseja marcar (0 -> return to Menu)");
        Task searched;

        while (true) {
            try {
                int getTaskByNumber = Integer.parseInt(userInput());

                if (getTaskByNumber != 0) {
                    searched = toDoList.getTaskInToDo(getTaskByNumber - 1);
                    break;
                } else {
                    response();
                }

            } catch (Exception e) {
                print.printIndexOutOfReach();
            }
        }

        searched.setStatus(Status.DONE);
        System.out.println("Task is now set to DONE");
    }
    public void removeTask() {
        System.out.println("Qual projeto abaixo você deseja excluir? \n");
        print.printOnlyIndexAndNameOfTask();
        System.out.println("\n Coloque o numero do projeto que você gostaria de excluir(0 -> return to Menu)");

        while (true) {
            try {
                int removeProjectByNumber = Integer.parseInt(userInput());
                if (removeProjectByNumber != 0) {
                    toDoList.remove(removeProjectByNumber - 1);
                    break;
                } else {
                    response();
                }
            } catch (Exception e) {
                print.printIndexOutOfReach();
            }
        }

        System.out.println("Tarefa removido");

    }

    public void update() {

        print.printUpdateOptions();
        switch (userInput()) {
            case "0":
                response();
                break;
            case "1":
                editName();
                break;
            case "2":
                editProject();
                break;
            case "3":
                editDate();
                break;
            default:
                print.printNotValiableOption();
                update();
        }
    }
    public void editName() {
        System.out.println("Editar nome da tarefa:\n ");
        print.printOnlyIndexAndNameOfTask();
        System.out.println("\n Coloque o numero da tarefa e o nome desejado (0 -> Return to Menu)");
        Task searched;

        while (true) {
            try {
                int getTitleByNumber = Integer.parseInt(userInput());

                if (getTitleByNumber != 0) {
                    searched = toDoList.getTaskInToDo(getTitleByNumber - 1);
                    break;
                } else {
                    response();
                }
            } catch (Exception e) {
                print.printIndexOutOfReach();
            }
        }

        System.out.println("mudar nome " + searched.getTitle() + " para?");
        String newName = userInput();
        searched.setTitle(newName);
        System.out.println("Nome alterado para " + newName);
    }

    public void editProject() {
        System.out.println("Aqui você pode alterar o nome do projeto\n ");
        print.printIndexAndNameAndProjectOfTask();
        System.out.println("\n Numero do projeto o qual deseja mudar(0 -> Return to Menu) ");
        Task searched;

        while (true) {
            try {
                int getProjectByNumber = Integer.parseInt(userInput());

                if(getProjectByNumber != 0){
                    searched = toDoList.getTaskInToDo(getProjectByNumber - 1);
                    break;
                }
                else{
                    response();
                }

            } catch (Exception e) {
                print.printIndexOutOfReach();
            }
        }

        System.out.println("Qual projeto" + searched.getTitle() + " pertence ?");
        String newProject = userInput();
        searched.setProjectName(newProject);
        System.out.println(searched.getTitle() + " Agora pertence a: " + newProject);
    }

    public void editDate() {
        System.out.println("Aqui você pode editar a data das taefas: \n ");
        print.printIndexAndNameAndDueDateOfTask();
        System.out.println("\n numero da tarefa que voce gostaria de fazer (0 -> Return to Menu)");

        try {
            int getProjectByNumber = Integer.parseInt(userInput());

            if(getProjectByNumber != 0){
            Task searched = toDoList.getTaskInToDo(getProjectByNumber - 1);
            System.out.println("Nova data para fazer " + searched.getTitle() + " abaixo (MM-dd-yyyy)");

            while (true) {
                try {
                    searched.setDueDate(SDF.parse(userInput()));
                    break;
                } catch (ParseException e) {
                    print.printWrongDateFormat();
                }
            }
            System.out.println(searched.getTitle() + "Data para fazer " + SDF.format(searched.getDueDate()));}
            else{
                response();
            }
        } catch (NumberFormatException e) {
            print.printIndexOutOfReach();
            editDate();
        }
    }
    public void editTask() {

        print.printEditTaskOptions();

        switch (userInput()) {
            case "0":
                response();
                break;
            case "1":
                removeTask();
                break;
            case "2":
                getTaskNumberAndChangeItToDone();
                break;
            case "3":
                update();
                break;
            default:
                print.printNotValiableOption();
                editTask();
        }
    }
    public void orderListOptions() {
        print.printSortingOptions();

        switch (userInput()) {
            case "0":
                response();
                break;
            case "1":
                print.printEntireList();
                break;
            case "2":
                print.printTasksByStatus(Status.PENDING);
                break;
            case "3":
                print.printTasksByStatus(Status.DONE);
                break;
            case "4":
                print.printTasksByProject();
                break;
            case "5":
                print.printTaskByDueDate();
                break;
            default:
                print.printNotValiableOption();
                orderListOptions();
        }
    }

}

