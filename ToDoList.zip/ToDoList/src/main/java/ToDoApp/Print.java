package ToDoApp;

import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Print {

    private List<Task> listOfToDos;
    private SimpleDateFormat sdf;

    Print(List<Task> listOfToDos) {
        this.listOfToDos = listOfToDos;
        this.sdf = new SimpleDateFormat("MM-dd-yyyy");
    }
    public void printHeading() {
        System.out.print(String.format("%1$-27s", "Tarefa"));
        System.out.print(String.format("%1$-27s", "PROJETO"));
        System.out.print(String.format("%1$-27s", "STATUS"));
        System.out.print(String.format("%1$-27s", "Data Criada"));
        System.out.println("Fazer até");
        System.out.println("--------------------------------" +
                "--------------------------------------------" +
                "----------------------------------------");
    }

    public void printEntireList() {
        printHeading();

        listOfToDos.forEach(this::printBody);
    }


    public void printTasksByStatus(Status status) {
        printHeading();

        listOfToDos.stream()
                .filter(task -> task.getStatus() == status)
                .forEach(this::printBody);

    }

    public void printTasksByProject() {
        Scanner reader = new Scanner(System.in);
        System.out.println("Selecione o projeto abaixo:");

        printIndexAndNameAndProjectOfTask();
        String project = reader.nextLine().toLowerCase().trim();

        printHeading();

        listOfToDos.stream()
                .filter(task -> task.getProjectName().toLowerCase().trim().equals(project))
                .forEach(this::printBody);

    }

    public void printBody(Task task) {

        System.out.print(listOfToDos.indexOf(task) + 1 + ". ");
        System.out.print(String.format("%1$-25s", task.getTitle()));
        System.out.print(String.format("%1$-25s", task.getProjectName()));
        System.out.print(String.format("%1$-28s", task.getStatus()));
        System.out.print(String.format("%1$-25s", sdf.format(task.getCreatedDate())));
        System.out.print(String.format("%1$-25s", sdf.format(task.getDueDate())));
        System.out.println("");
    }

    public void printTaskByDueDate() {
        printHeading();
        listOfToDos.sort(Comparator.comparing(Task::getDueDate));
        listOfToDos.stream().forEach(this::printBody);
    }

    public void printOnlyIndexAndNameOfTask() {
        for (Task list : listOfToDos) {
            System.out.print(listOfToDos.indexOf(list) + 1 + ". ");
            System.out.println(String.format("%1$-25s", list.getTitle()));
        }
    }
    public void printIndexAndNameAndProjectOfTask() {
        for (Task list : listOfToDos) {
            System.out.print(listOfToDos.indexOf(list) + 1 + ". ");
            System.out.print(String.format("%1$-25s", list.getTitle()));
            System.out.print(String.format("%1$-25s", list.getProjectName()));
            System.out.println();
        }
    }

    public void printIndexAndNameAndDueDateOfTask() {
        for (Task list : listOfToDos) {
            System.out.print(listOfToDos.indexOf(list) + 1 + ". ");
            System.out.print(String.format("%1$-25s", list.getTitle()));
            System.out.print(String.format("%1$-25s", sdf.format(list.getDueDate())));
            System.out.println();
        }
    }

    public void printWelcome() {

        System.out.println("\n Bem vindo ao ToDoList");
        System.out.println(" Tarefas pendentes: " + getBackAmount(Status.PENDING) + " | Tarefas complestas: " + getBackAmount(Status.DONE));
        System.out.println("\n Escolha uma opção");
    }

    public int getBackAmount(Status status){
        int counter = 0;

        for(Task list: listOfToDos){
            if(list.getStatus()== status){
                counter++;
            }
        }
        return counter;
    }

    public void printOptions() {
        System.out.println("---------------------------------------------");
        System.out.println(" (1) Mostrar lista de tarefas:");
        System.out.println(" (2) Adicionar nova tarefa");
        System.out.println(" (3) Editar tarefa (remover, marcar como concluida, atualizar)");
        System.out.println(" (4) Salvar e sair");
    }

    public void printNotValiableOption() {
        System.out.println("Digite uma das opções validas \n");
    }
    public void printWrongDateFormat() {
        System.out.println("O formato necessario é o SDF: (MM-dd-yyyy)");
    }
    public void printWhenQuitApplication() {
        System.out.println("Você saiu da aplicação, o ToDoList foi salvo");
    }
    public void printIndexOutOfReach() {
        System.out.println("Numero da tarefa não existe");
    }

    public void printUpdateOptions() {
        System.out.println("Press (1) Editar nome da tarefa");
        System.out.println("Press (2) Editar um projeto de uma tarefa especifica");
        System.out.println("Press (3) Editar data para completar a tarefa");
    }

    public void printEditTaskOptions() {
        System.out.println("Press (1) Remover itens da lista");
        System.out.println("Press (2) Marcar tarefas prontas");
        System.out.println("Press (3) Atualizar tarefas");
    }

    public void printSortingOptions() {
        System.out.println("Lista de tarefas:");
        System.out.println("(1): Mostrar todas as tarefas");
        System.out.println("(2): Todas as tarefas estão pendentes");
        System.out.println("(3): Todas as tarefas estão prontas");
        System.out.println("(4): Tarefas por projeto");
        System.out.println("(5): Data para concluir");
    }
