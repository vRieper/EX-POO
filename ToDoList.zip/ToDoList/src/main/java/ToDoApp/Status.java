package ToDoApp;

import java.io.Serializable;
public enum Status implements Serializable {
    DONE, PENDING;
    private static final long serialVersionUID = 8367141910137788612L;

}
