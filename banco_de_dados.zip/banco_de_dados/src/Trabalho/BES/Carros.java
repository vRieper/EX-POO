package Trabalho.PreparedStatement;

public class Carros {
    private int id;
    private String Carros;

    public Carros(){}

    public Carros(int id, String Carros){
        this.id = id;
        this.carrps = carros;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getCarros(){
        return carros;
    }

    public void setCarros(String carros){
        this.getCarros() = carros;
    }

    @Override
    public String toString() {
        return "Carros{" +
                "id=" + id +
                ", carros='" + carros + '\'' +
                '}';
    }
}