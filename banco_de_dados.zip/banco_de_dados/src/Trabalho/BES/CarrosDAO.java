package Trabalho.PreparedStatement;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaisesDAO {

    public void add(Carros carros){
        String script = "insert into trabalho (PAISES) values(?)";
        try(PreparedStatement stat = Conexao.getInstance().getConnection().prepareStatement(script)){
            stat.setString(1, paises.getCarros());

            stat.execute();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public void att(Carros carros){
        String script = "update trabalho set CARROS = ?";
        try(PreparedStatement stat = Conexao.getInstance().getConnection().prepareStatement(script)){
            stat.setString(1, paises.getCARROS());
            stat.setInt(2, paises.getId());

            stat.execute();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public void del(Carros carros){
        String script = "delete from trabalho where ID = ?";
        try(PreparedStatement stat = Conexao.getInstance().getConnection().prepareStatement(script)){
            stat.setInt(1, carros.getId());


            stat.execute();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public List<Carros> select(){
        String script = "select ID, CARROS from trabalho order by CARROS";
        List<Carros> lista = new ArrayList<>();
        try(PreparedStatement stat = Conexao.getInstance().getConnection().prepareStatement(script)){
            ResultSet resultSet = stat.executeQuery();

            while(resultSet.next()){
                Carros pais = new Carros();
                pais.setId(resultSet.getInt(1));
                pais.setPaises(resultSet.getString(2));
                lista.add(pais);
            }
            resultSet.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
        return lista;
    }

}