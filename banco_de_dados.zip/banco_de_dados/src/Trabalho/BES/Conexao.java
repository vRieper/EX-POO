package Trabalho.PreparedStatement;

import java.sql.*;

public class Conexao{

    private static Conexao instance;

    private Conexao(){}

    public static Conexao getInstance(){
        if(instance == null){
            instance = new Conexao();
        }
        return instance;
    }

    public Connection getConnection(){
        Connection conectar = null;
        try{
            conectar = DriverManager.getConnection("jdbc:sqlite:meu_banco.db");
        }catch (Exception e){
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
        return conectar;
    }
}