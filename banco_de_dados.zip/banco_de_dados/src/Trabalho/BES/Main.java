package Trabalho.PreparedStatement;

public class Main {
    public static void main(String[] args){

        PaisesDAO exe = new PaisesDAO();

        for(Carros p : exe.select()){
            System.out.println(p);
        }

        //Carros novoCarro = new Carros(0, "Hyundai");
        //exe.add(novoPais);

        //Carros attCarro = new Carros(5, "Cherry");
        //exe.att(attPais);

        //Carros delCarro = new Carros(1,"Volkswagen");
        //exe.del(delCarros);

    }
}